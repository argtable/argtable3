#include <stdio.h>
#include <argtable3.h>

int main(int argc, char *argv[]) {
    printf("hello world\n");
    struct arg_lit *help = arg_lit0("h", "help", "show help");
    struct arg_end *end = arg_end(20);
    void *argtable[] = { help, end };

    printf("Command line arguments:\n");

    if (arg_parse(argc, argv, argtable) == 0 && help->count) {
        printf("Help requested\n");
    }

    arg_freetable(argtable, sizeof(argtable) / sizeof(argtable[0]));
    return 0;
}
